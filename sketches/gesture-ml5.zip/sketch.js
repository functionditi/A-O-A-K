// -------------- GLOBAL VARS & ARRAYS --------------
// Kolam state
let pullis = [], framework = [], capArcs = [], startingPoints = [];
let dfsStack = [], visited = new Set(), lastVector = null;
let spacing = 50;  // distance between grid dots

// Handpose state
let video, handpose, hands = [];

// Pinch-to-start & thumb-tracking
let isPinching = false;
let trackThumb = false;
let pinchX = 0, pinchY = 0;
let pinchCandidateX = 0, pinchCandidateY = 0;
let pinchFrames = 0;
const pinchOnThreshold  = 5;  // frames to hold before locking start
const pinchOffThreshold = 5;  // frames to hold off before clearing

// Hover smoothing for dot selection
let hoverIdx = null;
let hoverFrames = 0;
const hoverThreshold = 5;  // frames to hover before committing

// Remember last committed thumb dot
let prevThumbIdx = null;

// Graphics layers
let gridLayer, drawingLayer, pointerLayer;
let cols, rows;

function setup() {
  createCanvas(640, 480);

  // compute how many dots fit
  cols = floor(width  / spacing);
  rows = floor(height / spacing);

  // --- camera + ml5 handpose ---
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();
  handpose = ml5.handpose(video, () => console.log('model ready'));
  handpose.on('predict', results => hands = results);

  // --- transparent graphics layers ---
  gridLayer    = createGraphics(width, height);
  drawingLayer = createGraphics(width, height);
  pointerLayer = createGraphics(width, height);
  gridLayer.clear();
  drawingLayer.clear();
  pointerLayer.clear();

  // draw the static grid of pullis
  makeGrid();
  drawGridDots();
}

function draw() {
  // composite: camera → grid → kolam drawing → overlays
  image(video, 0, 0);
  image(gridLayer, 0, 0);
  image(drawingLayer, 0, 0);

  // clear pointer layer and draw landmarks
  pointerLayer.clear();
  drawKeypointsOnLayer(pointerLayer);

  // handle first-pinch to set DFS start
  detectPinch();

  // thumb-hover logic once started
  if (trackThumb && hands.length > 0 && hands[0].landmarks) {
    handleThumbHover();
  }
  // show initial pinch circle before tracking
  else if (isPinching) {
    pointerLayer.fill(0, 0, 255);
    pointerLayer.noStroke();
    pointerLayer.ellipse(pinchX, pinchY, 80);
  }

  // draw DFS pointer dot
  drawPointerOnLayer(pointerLayer);

  // overlay it
  image(pointerLayer, 0, 0);
}

// ---------------- KEY HANDLING ----------------
function keyPressed() {
  // only allow manual keys after pinch start
  if (!trackThumb) return;

  if (key === '1')      extendSameDirection();
  else if (key === '2') extendTurn();
  else if (key === '0') terminateBranch();

  renderPermanentLayer();
}

// ----------- GRID CREATION & DOTS -----------
function makeGrid() {
  pullis = [];
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      pullis.push({ x: i * spacing + spacing/2,
                    y: j * spacing + spacing/2 });
    }
  }
}

function drawGridDots() {
  gridLayer.clear();
  gridLayer.noStroke();
  gridLayer.fill(0);
  for (let d of pullis) {
    gridLayer.ellipse(d.x, d.y, 5);
  }
}

// ----------- PINCH DETECTION & DFS INIT -----------
function detectPinch() {
  // skip after we've switched to thumb-tracking
  if (trackThumb) return;

  let currentlyPinching = false;
  let nearestIdx = -1;

  // only if hand data present
  if (hands.length > 0 && hands[0].landmarks) {
    let lm = hands[0].landmarks;
    let t = lm[4], i = lm[8];
    let d = dist(t[0], t[1], i[0], i[1]);

    if (d < 30) {
      currentlyPinching = true;
      // compute midpoint and snap candidate
      let mx = (t[0] + i[0]) / 2;
      let my = (t[1] + i[1]) / 2;

      // find nearest pulli
      let minD = Infinity;
      for (let idx = 0; idx < pullis.length; idx++) {
        let pt = pullis[idx];
        let dd = dist(mx, my, pt.x, pt.y);
        if (dd < minD) {
          minD = dd;
          nearestIdx = idx;
        }
      }
      pinchCandidateX = pullis[nearestIdx].x;
      pinchCandidateY = pullis[nearestIdx].y;

      // on first stable pinch, initialize DFS and begin thumb-tracking
      if (!trackThumb && pinchFrames + 1 >= pinchOnThreshold) {
        initDFSAt(nearestIdx);
        renderPermanentLayer();
        trackThumb = true;
      }
    }
  }

  // smooth the pinch on/off
  if (currentlyPinching) {
    pinchFrames = min(pinchFrames + 1, pinchOnThreshold);
  } else {
    pinchFrames = max(pinchFrames - 1, 0);
  }

  // finalize stable pinch
  if (!isPinching && pinchFrames === pinchOnThreshold) {
    isPinching = true;
    pinchX = pinchCandidateX;
    pinchY = pinchCandidateY;
  } else if (isPinching && pinchFrames === 0) {
    isPinching = false;
  }
}

function initDFSAt(startIndex) {
  // reset all Kolam state
  framework = [];
  capArcs = [];
  visited.clear();
  dfsStack = [];
  lastVector = null;
  startingPoints = [startIndex];
  visited.add(startIndex);
  dfsStack.push(startIndex);
  prevThumbIdx = startIndex;
}

// ----------- RENDER THE PERMANENT KOLAM -----------
function renderPermanentLayer() {
  drawingLayer.clear();
  drawingLayer.push();
  let angleArray = [];

  for (let i = 0; i < framework.length; i++) {
    let e = framework[i];
    let d1 = pullis[e.x], d2 = pullis[e.y];
    // base line
    drawingLayer.stroke(220);
    drawingLayer.strokeWeight(1);
    drawingLayer.line(d1.x, d1.y, d2.x, d2.y);

    // midpoint & angle
    let mx = (d1.x + d2.x)/2, my = (d1.y + d2.y)/2;
    let r = atan2(d2.y - d1.y, d2.x - d1.x);
    let deg = degrees(r);
    angleArray.push(deg);

    // decorations
    if (startingPoints.includes(e.x)) {
      drawLineByAngleOnLayer(drawingLayer, deg, mx, my, spacing, true);
      drawingLayer.stroke(0,0,255);
      loopAroundOnLayer(drawingLayer, d1, r, PI/4, PI*7/4);
    } else {
      let prevA = angleArray[i-1]||0, diff = deg - prevA;
      if (i%2===1) {
        if (!(diff===90||diff===-270))
          applyLoopAndStrokeOnLayer(drawingLayer, diff, r, d1);
        drawLineByAngleOnLayer(drawingLayer, deg, mx, my, spacing);
      } else {
        if (diff===90||diff===-270)
          applyLoopAndStrokeOnLayer(drawingLayer, diff, r, d1);
        else if (diff===0)
          applyLoopAndStrokeOnLayer(drawingLayer, diff, r+PI, d1);
        drawLineByAngleOnLayer(drawingLayer, deg, mx, my, spacing, true);
      }
    }
  }

  // cap arcs
  for (let a of capArcs) {
    drawingLayer.push();
    drawingLayer.stroke(0,0,255);
    loopAroundOnLayer(drawingLayer, a.dot, a.angle, a.start, a.stop);
    drawingLayer.pop();
  }
  drawingLayer.pop();
}

// ----------- DFS POINTER -----------
function drawPointerOnLayer(layer) {
  if (dfsStack.length > 0) {
    let d = pullis[dfsStack[dfsStack.length-1]];
    layer.fill(0,255,0);
    layer.stroke(0);
    layer.ellipse(d.x, d.y, 10);
  }
}

// ----------- DRAW HAND KEYPOINTS -----------
function drawKeypointsOnLayer(layer) {
  if (!hands.length) return;
  layer.noStroke();
  layer.fill(255,100);
  layer.stroke(255);
  for (let p of hands[0].landmarks) {
    layer.ellipse(p[0], p[1], 24);
  }
}

// ----------- DFS ACTIONS & HELPERS -----------
function extendSameDirection() {
  if (!lastVector || dfsStack.length===0) return;
  let cur = dfsStack[dfsStack.length-1];
  let {dx,dy} = lastVector;
  let x = pullis[cur].x + dx*spacing,
      y = pullis[cur].y + dy*spacing;
  let idx = findDotByCoord(x,y);
  if (idx>=0 && !visited.has(idx)) addEdge(cur, idx, {dx,dy});
  else extendRandom(cur);
}

function extendTurn() {
  if (!lastVector || dfsStack.length===0) return;
  let cur = dfsStack[dfsStack.length-1];
  let {dx,dy} = lastVector;
  // choose left/right so that vector matches lastVector for future
  let left = random()<0.5;
  let nv = left? {dx:-dy,dy:dx} : {dx:dy,dy:-dx};
  let x = pullis[cur].x + nv.dx*spacing,
      y = pullis[cur].y + nv.dy*spacing;
  let idx = findDotByCoord(x,y);
  if (idx>=0 && !visited.has(idx)) {
    addEdge(cur, idx, nv);
  } else {
    // try the opposite turn
    nv = left? {dx:dy,dy:-dx} : {dx:-dy,dy:dx};
    x = pullis[cur].x + nv.dx*spacing;
    y = pullis[cur].y + nv.dy*spacing;
    idx = findDotByCoord(x,y);
    if (idx>=0 && !visited.has(idx)) addEdge(cur, idx, nv);
    else extendRandom(cur);
  }
}

function terminateBranch() {
  if (!dfsStack.length) return;
  let currentIndex = dfsStack[dfsStack.length-1];
  let currentDot = pullis[currentIndex];
  let r_angle = lastVector
    ? atan2(lastVector.dy, lastVector.dx)+PI
    : 0;
  capArcs.push({
    dot: currentDot,
    angle: r_angle,
    start: PI/4,
    stop: dfsStack.length===1? PI*9/4 : PI*7/4
  });

  while (dfsStack.length>1) {
    let child = dfsStack.pop(),
        parent = dfsStack[dfsStack.length-1];
    let v = {
      dx: (pullis[parent].x - pullis[child].x)/spacing,
      dy: (pullis[parent].y - pullis[child].y)/spacing
    };
    framework.push({ x: child, y: parent, reverse: true, vector: v });
    lastVector = v;
  }
  dfsStack = [];
  lastVector = null;

  // new branch
  let unvis = pullis.map((_,i)=>i).filter(i=>!visited.has(i));
  if (unvis.length) {
    let nxt = random(unvis);
    visited.add(nxt);
    dfsStack.push(nxt);
    startingPoints.push(nxt);
  } else {
    console.log("All dots visited");
  }
}

function extendRandom(cur) {
  let neighbors = pullis.map((d,i)=>i)
    .filter(i=> !visited.has(i) && isAdjacent(pullis[cur], pullis[i]));
  if (neighbors.length) {
    let nxt = random(neighbors),
        d1 = pullis[cur],
        d2 = pullis[nxt],
        v = { dx:(d2.x-d1.x)/spacing, dy:(d2.y-d1.y)/spacing };
    addEdge(cur, nxt, v);
  } else {
    terminateBranch();
  }
}

function addEdge(a,b,v) {
  framework.push({ x:a, y:b, reverse:false, vector:v });
  visited.add(b);
  dfsStack.push(b);
  lastVector = v;
}

function findDotByCoord(x,y) {
  return pullis.findIndex(d=>d.x===x && d.y===y);
}

function isAdjacent(a,b) {
  return (abs(a.x-b.x)===spacing && a.y===b.y)
      || (a.x===b.x && abs(a.y-b.y)===spacing);
}

// ----------- DECORATION HELPERS -----------
function drawLineByAngleOnLayer(layer, deg, mx, my, s, rev=false) {
  let angle = (deg===90||deg===-90)
    ? rev?3*PI/4:PI/4
    : rev?PI/4:3*PI/4;
  let len = s*0.33;
  let x1 = mx - cos(angle)*len, y1 = my - sin(angle)*len;
  let x2 = mx + cos(angle)*len, y2 = my + sin(angle)*len;
  layer.stroke(0,0,255);
  layer.line(x1,y1,x2,y2);
}

function applyLoopAndStrokeOnLayer(layer, diff, r, dot) {
  layer.stroke(0,0,255);
  if (diff===0)
    loopAroundOnLayer(layer, dot, r, PI/4, PI*3/4);
  else if (diff===-90||diff===270)
    loopAroundOnLayer(layer, dot, r, PI/4, PI*5/4);
  else if (diff===90||diff===-270)
    loopAroundOnLayer(layer, dot, r+PI/2, PI/4, PI*5/4);
}

function loopAroundOnLayer(layer, dot, ang, st, sp) {
  layer.push();
  layer.translate(dot.x, dot.y);
  layer.rotate(ang);
  layer.noFill();
  layer.arc(0,0, spacing*0.66, spacing*0.66, st, sp);
  layer.pop();
}
